var _accidental_recog_8py =
[
    [ "AccidentalRecog", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html", "classrecognition_1_1_accidental_recog_1_1_accidental_recog" ],
    [ "THRESHOLD", "_accidental_recog_8py.html#a8d3d03944bba1b8d28a66cb135f1a980", null ]
];