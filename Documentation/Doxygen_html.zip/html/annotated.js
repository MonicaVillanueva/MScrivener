var annotated =
[
    [ "gui", "namespacegui.html", "namespacegui" ],
    [ "objects", "namespaceobjects.html", "namespaceobjects" ],
    [ "recognition", "namespacerecognition.html", "namespacerecognition" ],
    [ "writer", "namespacewriter.html", "namespacewriter" ]
];