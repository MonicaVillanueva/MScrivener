var classrecognition_1_1_accidental_recog_1_1_accidental_recog =
[
    [ "__init__", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html#a9f0fd90d1a61fe6651e0f48a2472ad1f", null ],
    [ "findAccidental", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html#a0b8fc0e1b579c50479ab556d1aaf478c", null ],
    [ "recogType", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html#a82d72d53a8d99f9e609626b8112cf650", null ],
    [ "accCenter", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html#a98ae968ae65ab7ab90bdf9027ff96039", null ],
    [ "type", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html#ad117cc54569d2c4ed1374f7b91e2bfbf", null ]
];