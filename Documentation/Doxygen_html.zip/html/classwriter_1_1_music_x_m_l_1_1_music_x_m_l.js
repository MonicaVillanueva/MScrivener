var classwriter_1_1_music_x_m_l_1_1_music_x_m_l =
[
    [ "__init__", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#ae62091dfcf5e37ebb1d25ea410737c3d", null ],
    [ "finalBarlineWriter", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#a0d68ea42c4236d27222f554204364127", null ],
    [ "headerWriter", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#aff6e4168ee286f38ad04c4bb56ed2f95", null ],
    [ "keySigAlteration", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#accec80b7012f49abd05c93ea9719f15e", null ],
    [ "objWriter", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#aae239ff5b9efa55c7a4ca2fadc63c990", null ],
    [ "write", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#ac311fd8492da67b4148ba3a8f9c534e8", null ],
    [ "measure_count", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#acf2f87c84df1649c3ac8f9b0670c5e78", null ],
    [ "measureAcc", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#a604412506da4fb2a4ea509e45f3de38b", null ],
    [ "r_count", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#a2eb4e28e60a22f8d107c34b75333468f", null ],
    [ "timeSig", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html#aa429dff3a2f6b84c64ea8cf062efb7bc", null ]
];