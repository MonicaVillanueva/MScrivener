var namespaces =
[
    [ "gui", "namespacegui.html", "namespacegui" ],
    [ "MScrivener", "namespace_m_scrivener.html", null ],
    [ "objects", "namespaceobjects.html", "namespaceobjects" ],
    [ "recognition", "namespacerecognition.html", "namespacerecognition" ],
    [ "writer", "namespacewriter.html", "namespacewriter" ]
];