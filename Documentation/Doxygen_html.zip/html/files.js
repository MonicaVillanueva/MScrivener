var files =
[
    [ "gui", "dir_11bc0974ce736ce9a6fadebbeb7a8314.html", "dir_11bc0974ce736ce9a6fadebbeb7a8314" ],
    [ "objects", "dir_645ec83fa4e243a732144956da80a200.html", "dir_645ec83fa4e243a732144956da80a200" ],
    [ "recognition", "dir_5443dc39785d12144f0f708ef47f23c0.html", "dir_5443dc39785d12144f0f708ef47f23c0" ],
    [ "writer", "dir_783af148810a357870d7ff46ed53bb09.html", "dir_783af148810a357870d7ff46ed53bb09" ],
    [ "MScrivener.py", "_m_scrivener_8py.html", "_m_scrivener_8py" ]
];