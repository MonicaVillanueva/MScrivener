var namespacerecognition_1_1_rest_recog =
[
    [ "RestRecog", "classrecognition_1_1_rest_recog_1_1_rest_recog.html", "classrecognition_1_1_rest_recog_1_1_rest_recog" ]
];