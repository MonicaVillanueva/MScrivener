var namespacerecognition_1_1_stave_recog =
[
    [ "StaveRecog", "classrecognition_1_1_stave_recog_1_1_stave_recog.html", "classrecognition_1_1_stave_recog_1_1_stave_recog" ]
];