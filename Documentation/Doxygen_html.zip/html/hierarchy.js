var hierarchy =
[
    [ "recognition.AccidentalRecog.AccidentalRecog", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html", null ],
    [ "gui.CreateGUI.CreateGUI", "classgui_1_1_create_g_u_i_1_1_create_g_u_i.html", null ],
    [ "recognition.DotRecog.DotRecog", "classrecognition_1_1_dot_recog_1_1_dot_recog.html", null ],
    [ "recognition.NoteRecog.NoteRecog", "classrecognition_1_1_note_recog_1_1_note_recog.html", null ],
    [ "object", null, [
      [ "gui.ScoreGUI.ScoreGUI", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html", null ],
      [ "objects.NoteObj.NoteObj", "classobjects_1_1_note_obj_1_1_note_obj.html", null ],
      [ "writer.MusicXML.MusicXML", "classwriter_1_1_music_x_m_l_1_1_music_x_m_l.html", null ]
    ] ],
    [ "objects.RestObj.RestObj", "classobjects_1_1_rest_obj_1_1_rest_obj.html", null ],
    [ "recognition.RestRecog.RestRecog", "classrecognition_1_1_rest_recog_1_1_rest_recog.html", null ],
    [ "recognition.StaveRecog.StaveRecog", "classrecognition_1_1_stave_recog_1_1_stave_recog.html", null ]
];