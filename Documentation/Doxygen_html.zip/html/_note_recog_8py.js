var _note_recog_8py =
[
    [ "NoteRecog", "classrecognition_1_1_note_recog_1_1_note_recog.html", "classrecognition_1_1_note_recog_1_1_note_recog" ],
    [ "PAD", "_note_recog_8py.html#aa32fd6e61b03bb182c6cbd7a9fdbf059", null ]
];