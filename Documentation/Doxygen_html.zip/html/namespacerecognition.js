var namespacerecognition =
[
    [ "AccidentalRecog", "namespacerecognition_1_1_accidental_recog.html", "namespacerecognition_1_1_accidental_recog" ],
    [ "DotRecog", "namespacerecognition_1_1_dot_recog.html", "namespacerecognition_1_1_dot_recog" ],
    [ "NoteRecog", "namespacerecognition_1_1_note_recog.html", "namespacerecognition_1_1_note_recog" ],
    [ "RestRecog", "namespacerecognition_1_1_rest_recog.html", "namespacerecognition_1_1_rest_recog" ],
    [ "StaveRecog", "namespacerecognition_1_1_stave_recog.html", "namespacerecognition_1_1_stave_recog" ]
];