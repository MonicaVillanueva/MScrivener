var classgui_1_1_score_g_u_i_1_1_score_g_u_i =
[
    [ "__init__", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a64282d12c02adb84a9cb49c3536673be", null ],
    [ "getStaveParams", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#aa5f62e79ac2ef30d4a0d8b52dd78f606", null ],
    [ "start", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a40ec686e3ec25bb6f63a7bce82a3f8e5", null ],
    [ "root", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#afa5c4afcc6d72ab78909dc21e9bcaee6", null ],
    [ "sheet", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a3edcbb312ddbe5fd344cd85f1ed0448d", null ],
    [ "status", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a91439b84e8046d2c492df98557d4c882", null ],
    [ "staveTotal", "classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a9cdabb7121d4a801ab63e903e129aa87", null ]
];