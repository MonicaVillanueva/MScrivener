var classrecognition_1_1_note_recog_1_1_note_recog =
[
    [ "__init__", "classrecognition_1_1_note_recog_1_1_note_recog.html#a3b28f85e7d3ec19bce74472d45c8b4d0", null ],
    [ "findHead", "classrecognition_1_1_note_recog_1_1_note_recog.html#a4611f7dd2906c39e317b8f360daf58b7", null ],
    [ "headCentres", "classrecognition_1_1_note_recog_1_1_note_recog.html#aaffc3210c87572761ffc1dbdf0744d02", null ],
    [ "noteAreas", "classrecognition_1_1_note_recog_1_1_note_recog.html#abf0450bca86669a5f2e2e34b9d4ef873", null ]
];