var classrecognition_1_1_dot_recog_1_1_dot_recog =
[
    [ "__init__", "classrecognition_1_1_dot_recog_1_1_dot_recog.html#a79d0c073da82aa26622fb16d8129b55a", null ],
    [ "findDottedRhythm", "classrecognition_1_1_dot_recog_1_1_dot_recog.html#a04a4d9e82448470f9b231aa96235c605", null ]
];