var _stave_recog_8py =
[
    [ "StaveRecog", "classrecognition_1_1_stave_recog_1_1_stave_recog.html", "classrecognition_1_1_stave_recog_1_1_stave_recog" ],
    [ "DIV", "_stave_recog_8py.html#a10b6ce815b33a2333750c440931b7a87", null ],
    [ "WHITE", "_stave_recog_8py.html#ab873102101bf7ee249d0504f2d9f817e", null ]
];