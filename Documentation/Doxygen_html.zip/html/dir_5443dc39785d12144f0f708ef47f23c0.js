var dir_5443dc39785d12144f0f708ef47f23c0 =
[
    [ "__init__.py", "recognition_2____init_____8py.html", null ],
    [ "AccidentalRecog.py", "_accidental_recog_8py.html", "_accidental_recog_8py" ],
    [ "DotRecog.py", "_dot_recog_8py.html", "_dot_recog_8py" ],
    [ "NoteRecog.py", "_note_recog_8py.html", "_note_recog_8py" ],
    [ "RestRecog.py", "_rest_recog_8py.html", "_rest_recog_8py" ],
    [ "StaveRecog.py", "_stave_recog_8py.html", "_stave_recog_8py" ]
];