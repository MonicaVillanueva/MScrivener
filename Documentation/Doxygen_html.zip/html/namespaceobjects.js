var namespaceobjects =
[
    [ "NoteObj", "namespaceobjects_1_1_note_obj.html", "namespaceobjects_1_1_note_obj" ],
    [ "RestObj", "namespaceobjects_1_1_rest_obj.html", "namespaceobjects_1_1_rest_obj" ]
];