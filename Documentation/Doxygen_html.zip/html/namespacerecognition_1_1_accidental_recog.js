var namespacerecognition_1_1_accidental_recog =
[
    [ "AccidentalRecog", "classrecognition_1_1_accidental_recog_1_1_accidental_recog.html", "classrecognition_1_1_accidental_recog_1_1_accidental_recog" ]
];