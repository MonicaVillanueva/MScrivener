var _rest_recog_8py =
[
    [ "RestRecog", "classrecognition_1_1_rest_recog_1_1_rest_recog.html", "classrecognition_1_1_rest_recog_1_1_rest_recog" ],
    [ "PAD", "_rest_recog_8py.html#ab22aafd852fd0d5b5c7208210e1f3b38", null ],
    [ "THRESHOLD", "_rest_recog_8py.html#ae724b6f37f8c1c19f91b77522174cc52", null ]
];