var _dot_recog_8py =
[
    [ "DotRecog", "classrecognition_1_1_dot_recog_1_1_dot_recog.html", "classrecognition_1_1_dot_recog_1_1_dot_recog" ],
    [ "THRESHOLD", "_dot_recog_8py.html#a174ef2aae1178e7758e21b0d793c4d0b", null ]
];