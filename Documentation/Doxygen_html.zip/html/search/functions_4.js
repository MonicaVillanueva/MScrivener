var searchData=
[
  ['getstaveparams',['getStaveParams',['../classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#aa5f62e79ac2ef30d4a0d8b52dd78f606',1,'gui::ScoreGUI::ScoreGUI']]]
];
