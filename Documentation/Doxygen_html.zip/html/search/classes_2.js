var searchData=
[
  ['dotrecog',['DotRecog',['../classrecognition_1_1_dot_recog_1_1_dot_recog.html',1,'recognition::DotRecog']]]
];
