var searchData=
[
  ['savepath',['savePath',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#ae17bcb8b55d9248684072ae291e4f1bb',1,'gui::CreateGUI::CreateGUI']]],
  ['scoreg',['scoreG',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a59cfee90f7cc0d828967dbbfdab83aba',1,'gui::CreateGUI::CreateGUI']]],
  ['scorepath',['scorePath',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#aa0f116d24a094ba99815dd9e9adcf1e2',1,'gui::CreateGUI::CreateGUI']]],
  ['sheet',['sheet',['../classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a3edcbb312ddbe5fd344cd85f1ed0448d',1,'gui::ScoreGUI::ScoreGUI']]],
  ['spinvalues',['spinValues',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a40154fb1fc8366aff75d0e9b986e4107',1,'gui::CreateGUI::CreateGUI']]],
  ['status',['status',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a035b773399191fd3d974118d991b5d4c',1,'gui.CreateGUI.CreateGUI.status()'],['../classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a91439b84e8046d2c492df98557d4c882',1,'gui.ScoreGUI.ScoreGUI.status()']]],
  ['stavesareas',['stavesAreas',['../classrecognition_1_1_stave_recog_1_1_stave_recog.html#aec43b6a3c3888d7981274937d087b5da',1,'recognition::StaveRecog::StaveRecog']]],
  ['stavetotal',['staveTotal',['../classgui_1_1_score_g_u_i_1_1_score_g_u_i.html#a9cdabb7121d4a801ab63e903e129aa87',1,'gui::ScoreGUI::ScoreGUI']]]
];
