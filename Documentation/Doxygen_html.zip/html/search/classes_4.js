var searchData=
[
  ['noteobj',['NoteObj',['../classobjects_1_1_note_obj_1_1_note_obj.html',1,'objects::NoteObj']]],
  ['noterecog',['NoteRecog',['../classrecognition_1_1_note_recog_1_1_note_recog.html',1,'recognition::NoteRecog']]]
];
