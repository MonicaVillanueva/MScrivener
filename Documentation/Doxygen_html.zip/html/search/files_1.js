var searchData=
[
  ['accidentalrecog_2epy',['AccidentalRecog.py',['../_accidental_recog_8py.html',1,'']]]
];
