var searchData=
[
  ['canvas',['canvas',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a7231c34808d1623b76a4121dff2c1685',1,'gui::CreateGUI::CreateGUI']]],
  ['centres',['centres',['../classrecognition_1_1_rest_recog_1_1_rest_recog.html#a4ad95772e279c066b85e837f7fb58d31',1,'recognition::RestRecog::RestRecog']]],
  ['correct',['correct',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a506968e5746e21e3180b4c30a870f63c',1,'gui::CreateGUI::CreateGUI']]],
  ['current',['current',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#af6108bc2bb72fd79043a7a168886fea2',1,'gui::CreateGUI::CreateGUI']]],
  ['cvimg',['cvimg',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#afccfd766346cfaa84dace70310799bf8',1,'gui::CreateGUI::CreateGUI']]]
];
