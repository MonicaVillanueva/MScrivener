var searchData=
[
  ['nextbutton',['nextButton',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a96044fd9f4076e1ddda210095d846dd0',1,'gui::CreateGUI::CreateGUI']]],
  ['noteareas',['noteAreas',['../classrecognition_1_1_note_recog_1_1_note_recog.html#abf0450bca86669a5f2e2e34b9d4ef873',1,'recognition::NoteRecog::NoteRecog']]],
  ['num',['num',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a575245b3657ddf45321fd92701ffc9ea',1,'gui::CreateGUI::CreateGUI']]]
];
