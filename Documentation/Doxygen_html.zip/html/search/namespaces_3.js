var searchData=
[
  ['accidentalrecog',['AccidentalRecog',['../namespacerecognition_1_1_accidental_recog.html',1,'recognition']]],
  ['dotrecog',['DotRecog',['../namespacerecognition_1_1_dot_recog.html',1,'recognition']]],
  ['noterecog',['NoteRecog',['../namespacerecognition_1_1_note_recog.html',1,'recognition']]],
  ['recognition',['recognition',['../namespacerecognition.html',1,'']]],
  ['restrecog',['RestRecog',['../namespacerecognition_1_1_rest_recog.html',1,'recognition']]],
  ['staverecog',['StaveRecog',['../namespacerecognition_1_1_stave_recog.html',1,'recognition']]]
];
