var searchData=
[
  ['isline',['isLine',['../classrecognition_1_1_stave_recog_1_1_stave_recog.html#a90749dfa1b80360f3df15c632c282092',1,'recognition::StaveRecog::StaveRecog']]],
  ['isstave',['isStave',['../classobjects_1_1_note_obj_1_1_note_obj.html#a891fc2342bd854fef79a55205b867e94',1,'objects::NoteObj::NoteObj']]]
];
