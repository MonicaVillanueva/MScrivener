var searchData=
[
  ['scoregui_2epy',['ScoreGUI.py',['../_score_g_u_i_8py.html',1,'']]],
  ['staverecog_2epy',['StaveRecog.py',['../_stave_recog_8py.html',1,'']]]
];
