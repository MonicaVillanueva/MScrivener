var searchData=
[
  ['restobj',['RestObj',['../classobjects_1_1_rest_obj_1_1_rest_obj.html',1,'objects::RestObj']]],
  ['restrecog',['RestRecog',['../classrecognition_1_1_rest_recog_1_1_rest_recog.html',1,'recognition::RestRecog']]]
];
