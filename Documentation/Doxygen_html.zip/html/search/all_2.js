var searchData=
[
  ['blackimg',['blackimg',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#ab6245897b777b69cd7ffa270c789442d',1,'gui::CreateGUI::CreateGUI']]]
];
