var searchData=
[
  ['scoregui',['ScoreGUI',['../classgui_1_1_score_g_u_i_1_1_score_g_u_i.html',1,'gui::ScoreGUI']]],
  ['staverecog',['StaveRecog',['../classrecognition_1_1_stave_recog_1_1_stave_recog.html',1,'recognition::StaveRecog']]]
];
