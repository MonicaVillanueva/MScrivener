var searchData=
[
  ['next',['next',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a46cde766a773f2b718b591682d39ce7c',1,'gui::CreateGUI::CreateGUI']]],
  ['next2',['next2',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a16f323d7b04d26123b7635c173e9775a',1,'gui::CreateGUI::CreateGUI']]],
  ['nextpattern',['nextPattern',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#ab864d452a3ed2bd9cabbeb6e3457f551',1,'gui::CreateGUI::CreateGUI']]],
  ['noblack',['noBlack',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a931fda69cd2fe97fb98c382075bbd5a6',1,'gui::CreateGUI::CreateGUI']]],
  ['noise',['noise',['../classrecognition_1_1_rest_recog_1_1_rest_recog.html#aef8c3b1102f95be0086676e2b2d3411b',1,'recognition::RestRecog::RestRecog']]]
];
