var searchData=
[
  ['dotrecog_2epy',['DotRecog.py',['../_dot_recog_8py.html',1,'']]]
];
