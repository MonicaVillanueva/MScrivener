var searchData=
[
  ['next',['next',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a46cde766a773f2b718b591682d39ce7c',1,'gui::CreateGUI::CreateGUI']]],
  ['next2',['next2',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a16f323d7b04d26123b7635c173e9775a',1,'gui::CreateGUI::CreateGUI']]],
  ['nextbutton',['nextButton',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a96044fd9f4076e1ddda210095d846dd0',1,'gui::CreateGUI::CreateGUI']]],
  ['nextpattern',['nextPattern',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#ab864d452a3ed2bd9cabbeb6e3457f551',1,'gui::CreateGUI::CreateGUI']]],
  ['noblack',['noBlack',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a931fda69cd2fe97fb98c382075bbd5a6',1,'gui::CreateGUI::CreateGUI']]],
  ['noise',['noise',['../classrecognition_1_1_rest_recog_1_1_rest_recog.html#aef8c3b1102f95be0086676e2b2d3411b',1,'recognition::RestRecog::RestRecog']]],
  ['noteareas',['noteAreas',['../classrecognition_1_1_note_recog_1_1_note_recog.html#abf0450bca86669a5f2e2e34b9d4ef873',1,'recognition::NoteRecog::NoteRecog']]],
  ['noteobj',['NoteObj',['../classobjects_1_1_note_obj_1_1_note_obj.html',1,'objects::NoteObj']]],
  ['noteobj_2epy',['NoteObj.py',['../_note_obj_8py.html',1,'']]],
  ['noterecog',['NoteRecog',['../classrecognition_1_1_note_recog_1_1_note_recog.html',1,'recognition::NoteRecog']]],
  ['noterecog_2epy',['NoteRecog.py',['../_note_recog_8py.html',1,'']]],
  ['num',['num',['../classgui_1_1_create_g_u_i_1_1_create_g_u_i.html#a575245b3657ddf45321fd92701ffc9ea',1,'gui::CreateGUI::CreateGUI']]]
];
