var searchData=
[
  ['accidentalrecog',['AccidentalRecog',['../classrecognition_1_1_accidental_recog_1_1_accidental_recog.html',1,'recognition::AccidentalRecog']]]
];
