var namespacerecognition_1_1_dot_recog =
[
    [ "DotRecog", "classrecognition_1_1_dot_recog_1_1_dot_recog.html", "classrecognition_1_1_dot_recog_1_1_dot_recog" ]
];