var namespacerecognition_1_1_note_recog =
[
    [ "NoteRecog", "classrecognition_1_1_note_recog_1_1_note_recog.html", "classrecognition_1_1_note_recog_1_1_note_recog" ]
];