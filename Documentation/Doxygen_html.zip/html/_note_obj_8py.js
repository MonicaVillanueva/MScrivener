var _note_obj_8py =
[
    [ "NoteObj", "classobjects_1_1_note_obj_1_1_note_obj.html", "classobjects_1_1_note_obj_1_1_note_obj" ],
    [ "DIV_LONG", "_note_obj_8py.html#a1e04cac95043d7a9a0c86778d70323a5", null ],
    [ "DIV_SHORT", "_note_obj_8py.html#a38c66f096622c9c0a74055e360f046a1", null ],
    [ "THRESHOLD", "_note_obj_8py.html#abfc7a635a780cf02d3d500e6d48a9f5b", null ],
    [ "THRESV", "_note_obj_8py.html#ac46495c35a850575cca633e9379befc1", null ],
    [ "WHITE", "_note_obj_8py.html#ae77ddd814c9ba0f3e72135fb06d3cc09", null ]
];