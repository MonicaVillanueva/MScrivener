var _create_g_u_i_8py =
[
    [ "CreateGUI", "classgui_1_1_create_g_u_i_1_1_create_g_u_i.html", "classgui_1_1_create_g_u_i_1_1_create_g_u_i" ],
    [ "THRESHOLD", "_create_g_u_i_8py.html#a2b2dc58fc0aaafe67c472cecce2afead", null ]
];