var namespacegui =
[
    [ "CreateGUI", "namespacegui_1_1_create_g_u_i.html", "namespacegui_1_1_create_g_u_i" ],
    [ "ScoreGUI", "namespacegui_1_1_score_g_u_i.html", "namespacegui_1_1_score_g_u_i" ]
];