var classrecognition_1_1_stave_recog_1_1_stave_recog =
[
    [ "__init__", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a9dc30c90313a95e5b8962447075d71da", null ],
    [ "findStave", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a518e504fbe2e3b1dfebb771e972de009", null ],
    [ "findUpper", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a5aff76a0792515f1f2485cf30a40f076", null ],
    [ "isLine", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a90749dfa1b80360f3df15c632c282092", null ],
    [ "d", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a042f6083cf0679496b084084dc246161", null ],
    [ "d_list", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a068e31a1df7c3c57580796bf39a7475d", null ],
    [ "stavesAreas", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#aec43b6a3c3888d7981274937d087b5da", null ],
    [ "t", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a93f0474ab7ea1e9df27b23847c1afdf2", null ],
    [ "t_list", "classrecognition_1_1_stave_recog_1_1_stave_recog.html#a39dc1f9d3ef854d6a61a421e17d6b83e", null ]
];